import java.io.*;
import java.net.*;
import java.util.*;

public class QuizServer {
    private static final int PORT = 12345;
    private static List<ClientHandler> clients = new ArrayList<>();
    private static final List<Question> questions = Arrays.asList(
        new Question("Which layer of the OSI model is responsible for ensuring error-free data transmission?", "Transport layer"),
        new Question("Which of the following is a transport layer protocol?", "TCP"),
        new Question("The standard port number for HTTP is", "80"),
        new Question("The process of dividing a network into smaller subnetworks is called", "Subnetting"),
        new Question("What protocol is used to resolve an IP address to a MAC address?", "ARP")
    );

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Quiz Server started on port " + PORT);
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("New client connected: " + socket.getInetAddress());
                ClientHandler clientHandler = new ClientHandler(socket);
                clients.add(clientHandler);
                new Thread(clientHandler).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ClientHandler implements Runnable {
        private Socket socket;
        private BufferedReader in;
        private PrintWriter out;
        private int score = 0;

        public ClientHandler(Socket socket) {
            this.socket = socket;
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            try {
                out.println("Welcome to the Quiz Game!");
                for (Question q : questions) {
                    // Display the question
                    out.println();
                    out.println("Question: " + q.getQuestion());


                    // Read client response
                    String answer = in.readLine();

                    // Check and provide feedback
                    if (answer != null && answer.equalsIgnoreCase(q.getCorrectAnswer())) {
                        score++;
                        out.println("Correct!");
                    } else {
                        out.println("Wrong! Correct answer is: " + q.getCorrectAnswer());
                    }
                }

                // Display final score
                out.println();
                out.println("Your final score is: " + score);
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static class Question {
        private String question;
        private String correctAnswer;

        public Question(String question, String correctAnswer) {
            this.question = question;
            this.correctAnswer = correctAnswer;
        }

        public String getQuestion() {
            return question;
        }

        public String getCorrectAnswer() {
            return correctAnswer;
        }
    }
}
